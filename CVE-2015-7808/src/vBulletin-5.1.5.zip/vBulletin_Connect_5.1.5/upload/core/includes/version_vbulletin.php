<?php if(!defined('VB_ENTRY')) die('Access denied.');

define('FILE_VERSION_VBULLETIN', '');

?>