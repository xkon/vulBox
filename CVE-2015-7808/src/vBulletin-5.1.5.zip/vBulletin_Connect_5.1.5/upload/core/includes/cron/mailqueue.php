<?php if(!defined('VB_ENTRY')) die('Access denied.');
/*======================================================================*\
|| #################################################################### ||
|| # vBulletin Blog 5.1.5
|| # ---------------------------------------------------------------- # ||
|| # Copyright �2000-2015 vBulletin Solutions Inc. All Rights Reserved. ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------- VBULLETIN IS NOT FREE SOFTWARE ---------------- # ||
|| # vbulletin.com | vbulletin.com/license.html                       # ||
|| #################################################################### ||
\*======================================================================*/

// ######################## SET PHP ENVIRONMENT ###########################
error_reporting(E_ALL & ~E_NOTICE);

if (vB::getDatastore()->getOption('mailqueue'))
{

	$mailqueue = vB_Mail_Queue::fetchInstance();
	$mailqueue ->execQueue();

	log_cron_action('execMailQueue', array(), false);
}

/*======================================================================*\
|| ####################################################################
|| # CVS: $Revision: 25612 $
|| ####################################################################
\*======================================================================*/
